LVINIT JULY 2026 — MAILCHIMP PRODUCTION PACKAGE

READY:
- Production HTML created for Mailchimp custom-code use.
- Mailchimp unsubscribe link uses *|UNSUB|*
- Manage Preferences uses *|UPDATE_PROFILE|*
- LVINIT, YouTube, Instagram links are live.
- Correct Mikey headshot crop included.
- Scofield Group logo asset included.
- Walkthrough thumbnail included.
- Email preheader text added.
- Production image paths point to:
  https://lvinit.com/email-assets/2026-07/

IMPORTANT BEFORE SEND:
1. Upload every file inside email-assets/2026-07/ to the matching public path on lvinit.com.
2. Confirm each image URL loads publicly in an incognito browser.
3. Replace development-watch-placeholder.jpg with the REAL Four Seasons / MacDonald Highlands image before sending. Keep the exact same filename if you want zero HTML edits.
4. Equal Housing is currently rendered as compliance text, not an official logo image.
5. Import the production HTML into Mailchimp's custom-code email/template workflow.
6. Send a TEST email to yourself before sending to the audience.
7. Verify desktop Gmail and mobile Gmail.
8. Click every CTA, social link, listing link, unsubscribe link, and manage-preferences link.
9. Confirm the audience is permission-based and appropriately subscribed before marketing send.

FILES:
- july-2026-MAILCHIMP.html = production HTML
- email-assets/2026-07/ = assets to host on lvinit.com

DO NOT SEND THE OLD SELF-CONTAINED PREVIEW HTML.
